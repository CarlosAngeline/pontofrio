
$( document ).ready(function() {
   $( ".caixa1" ).click(function(e) {
   $('.caixa1').removeClass("ativo-background");
   $(this).addClass("ativo-background");
  
 });
   });